import java.io.File;

import jxl.Cell;
import jxl.CellType;
import jxl.LabelCell;
import jxl.NumberCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.Number;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;



public class MainOutPut {

	public MainOutPut() {
		// �Զ����ɵĹ��캯�����
	}

	public static void main(String[] args) {
		// �Զ����ɵķ������
		File target= new File("Mygrades.xls");
		processScoreTable(target)  ;

	}
	public static void processScoreTable(File input) {
		//  �Զ����ɵķ������
		//����excel�ļ�
        Sheet sheet;
        Workbook book;
        int m=100;
        double average,GPA = 0;
        double sum1 =0,sum2=0;
        Cell cell;
 //���������ŵ�Ԫ���е�ֵ
        String LessonName[]=new String[m];
        double Credit[]=new double[m];
        int Score[]=new int[m];
        try { 
        	 book= Workbook.getWorkbook(input);
            //��õ�һ������������
        	sheet=book.getSheet(0);
            int rsColumns = sheet.getColumns();//��ȡSheet������������������
            int rsRows = sheet.getRows();//��ȡSheet������������������
            for(int j=0;j<rsColumns;j++){
           for(int i=1;i<rsRows;i++)
            {	
                cell=sheet.getCell(j,i);//���У��У�
                //cell2=sheet.getCell(j,i);
                //cell3=sheet.getCell(j,i);
                if(j==0){
                	if(cell.getType() == CellType.LABEL){
                		LabelCell cell1 = (LabelCell)cell;
                		LessonName[i] = cell1.getString();
                	}
                }
                if(j==1){
                	        if(cell.getType() == CellType.NUMBER){
                    		NumberCell cell2 = (NumberCell)cell;
                    		Credit[i] = cell2.getValue();
                    	}
                }
                if(j==2){
                    	if(cell.getType() == CellType.NUMBER){
                    		NumberCell cell3 = (NumberCell)cell;
                    		Score[i] =  (int) cell3.getValue();
                        }
                }
                
                if("".equals(cell.getContents())==true)    //�����ȡ������Ϊ��
                    break;
            }
            }
            book.close();

         //���޸ĺ�����������һ���µ�excel�ļ�
            String title[]={"�γ�����","ѧ��","�ɼ�","��Ȩƽ����","�ۺϼ�ȨGPA"};
            WritableWorkbook book1= Workbook.createWorkbook(new File("Mynewgrades.xls"));
            WritableSheet sheet1=book1.createSheet("Mynewgrades",0);
            sheet1.addCell(new Number(3,1,average));
  		  sheet1.addCell(new Number(4,1,GPA));
           for(int i=0;i<5;i++){
        	   sheet1.addCell(new Label(i,0,title[i]));
           }
           for(int i = 1;i<rsRows;i++){
        	   for(int j=0;j<3;j++){
        		   if(j==0){sheet1.addCell(new Label(j,i,LessonName[i]));}
        		   if(j==1){sheet1.addCell(new Number(j,i,Credit[i]));}
        		   if(j==2){sheet1.addCell(new Number(j,i,Score[i]));}
        	   }
           }
           book1.write();
           book1.close();
        }                                                          
        catch(Exception e)  { } 
        }


 //���ɼ���������
            for(int i=rsRows;i>1;i--){
            	for(int j=1;j<i;j++){
            		if(Score[j]<Score[j+1]){
            			Score[0]=Score[j];Score[j]=Score[j+1];Score[j+1]=Score[0];
            			Credit[0]=Credit[j];Credit[j]=Credit[j+1];Credit[j+1]=Credit[0];
            			LessonName[0]=LessonName[j];LessonName[j]=LessonName[j+1];LessonName[j+1]=LessonName[0];
            		}
            	}
            }
 //�����Ȩƽ����
            for(int i=1;i<rsRows;i++){
            	sum1= (sum1+Score[i]*Credit[i]);
            	sum2=sum2+Credit[i];
            }
            average=sum1/sum2;
 //�����ۺϼ�ȨGPA
            if(average>=90) GPA=4.0;
			else if(average>=85)GPA=3.7;
			else if(average>=82)GPA=3.3;
			else if(average>=78)GPA=3.0;
			else if(average>=75)GPA=2.7;
			else if(average>=72)GPA=2.3;
			else if(average>=68)GPA=2.0;
			else if(average>=64)GPA=1.5;
			else if(average>=60)GPA=1.0;
			else if(average<60)GPA=0;
            /*System.out.println(GPA);
            /*for(int i=1;i<rsRows;i++){
            	System.out.println(LessonName[i]+Credit[i]+Score[i]);
            }*/

   
}